﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vehiculos;

namespace HerenciaTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Auto auto1 = new Auto();
            Auto auto2 = new Auto();
            Moto moto = new Moto();
            Camion camion = new Camion();
                        
           
            Console.WriteLine(auto1.MostrarAuto());
            Console.WriteLine(auto2.MostrarAuto());
            Console.WriteLine(moto.MostrarMoto());
            Console.WriteLine(camion.MostrarCamion());

            Console.ReadLine();
        }
    }
}
