﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase._06.Entidades
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Tempera temp1 = new Tempera(ConsoleColor.Blue, "Bic", 123);
            Console.WriteLine(Tempera.mostrar(temp1));*/

            Paleta paleta = 3;
            Console.WriteLine((string)paleta);


            Console.ReadKey();


        }
    }
}
