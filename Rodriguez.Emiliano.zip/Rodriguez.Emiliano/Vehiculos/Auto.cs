﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Vehiculos
{
    public class Auto : Vehiculo
    {
        protected int _cantidadCilindros;

        public Auto(string patente, EMarca marca, int cantidadRuedas, int cantidadCilindros) : base(patente, marca, cantidadRuedas)
        {
            _cantidadCilindros = cantidadCilindros;
        }

        public string MostrarAuto()
        {
            return base.MostrarVehiculo() + " " + this._cantidadCilindros.ToString();
        }
    }
}
