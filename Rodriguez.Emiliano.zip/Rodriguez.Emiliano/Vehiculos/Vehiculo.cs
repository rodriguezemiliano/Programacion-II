﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    public class Vehiculo
    {
        protected string _patente;
        protected EMarca _marca;
        protected int _cantidadRuedas;

        public Vehiculo(string patente, EMarca marca, int cantidadRuedas)
        {
           this._patente = patente;
           this._marca = marca;
           this._cantidadRuedas = cantidadRuedas;
        }

        public string MostrarVehiculo()
        {
            return this._patente + " " + this._marca.ToString() + " " + this._cantidadRuedas.ToString();
        }
    }
}
