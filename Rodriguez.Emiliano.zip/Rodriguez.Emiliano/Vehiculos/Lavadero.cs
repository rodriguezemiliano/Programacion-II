﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        private double _precioAuto;
        private double _precioMoto;
        private double _precioCamion;


        public string MiLavadero
        {
            get
            {
                string retorno = = this._precioMoto.ToString() + this._precioAuto.ToString() + this._precioCamion.ToString(); ;

                foreach (Vehiculo item in this._vehiculos)
                {
                    if (item is Moto)
                    {
                        retorno += ((Moto)item).MostrarMoto();
                    }

                    else if(item is Auto)
                    {
                        retorno += ((Auto)item).MostrarAuto();
                    }

                    else
                    {
                        retorno += ((Camion)item).MostrarCamion();
                    }
                }
                
                return retorno;
            }
        }
        
            
        

        public List<Vehiculo> Vehiculos
        {

            get
            {                
                return  this._vehiculos; 
            }

        }

        public Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        public Lavadero(double precioAuto, double precioMoto, double precioCamion)
        {
            this._precioAuto = precioAuto;
            this._precioMoto = precioMoto;
            this._precioCamion = precioCamion;
        }

        public static bool operator == (Lavadero lavadero, Vehiculo vehiculo)
        {
            bool retorno = false;

            foreach (Vehiculo item in lavadero.Vehiculos)
            {
                if (vehiculo)
                {

                }
            }

            return retorno;

        }


    }
}
