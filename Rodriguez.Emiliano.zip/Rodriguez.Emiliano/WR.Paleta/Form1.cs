using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase_06_Entidades;

namespace WR.Paleta
{
  public partial class Form1 : Form
  {
    Clase_06_Entidades.Paleta paleta;

    public Form1()
    {
      InitializeComponent();
    }

    private void btn_Mas_Click(object sender, EventArgs e)
    {
      frmPaleta frmPaleta = new frmPaleta();
      frmPaleta.ShowDialog();
      paleta += frmPaleta.tempera;
      MessageBox.Show(paleta.Mostrar());

    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }
  }
}
