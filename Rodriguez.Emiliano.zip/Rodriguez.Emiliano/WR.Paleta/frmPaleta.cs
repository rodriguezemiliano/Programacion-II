using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase_06_Entidades;

namespace WR.Paleta
{
  public partial class frmPaleta : Form
  {
    public Tempera tempera;
    public frmPaleta()
    {
      InitializeComponent();
    }

    private void frmPaleta_Load(object sender, EventArgs e)
    {
      this.cmb_Color.DataSource = Enum.GetValues(typeof (ConsoleColor));
    }

    private void btn_Aceptar_Click(object sender, EventArgs e)
    {
       tempera = new Tempera(Convert.ToSByte(txt_Cantidad), (ConsoleColor) cmb_Color.SelectedItem, txt_Marca.ToString());

    }
  }
}
