﻿using System;

namespace ClassLibrary3
{
    public class Class1
    {
    }
}
