﻿using System;

namespace Entidades.Genericas
{
    public class Class1
    {
    }
}
