﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Deposito
{
    public class DepositoDeAutos
    {
        private int _capacidadMaxima;
        List<Auto> _lista;


        public DepositoDeAutos(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Auto>();
        }


        #region Operadores

        public static bool operator+(DepositoDeAutos deposito, Auto auto)
        {
            bool retorno = false;

            if(deposito._lista.Capacity < deposito._capacidadMaxima)
            {
                deposito._lista.Add(auto);
                retorno = true;
            }

            return retorno;
        }

        public static bool operator -(DepositoDeAutos deposito, Auto auto)
        {
            bool retorno = false;

            if (deposito.GetIndice(auto) > -1)
            {
                deposito._lista.Remove(auto);
                retorno = true;
            }

            return retorno;
        }

        #endregion


        #region Metodos

        private int GetIndice(Auto auto)
        {
            int retorno = -1;

            for (int i = 0; i < this._lista.Count ; i++)
            {
                if (this._lista[i] == auto)
                {
                    retorno = i;
                }
            }

            return retorno;
        }

        public bool Agregar(Auto auto)
        {
            return this + auto;
        }

        public bool Remover(Auto auto)
        {
            return this - auto;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Capacidad Maxima: ");
            sb.AppendLine(this._capacidadMaxima.ToString());
            
            sb.AppendLine("Listado de autos: ");

            foreach (Auto item in this._lista)
            {
                sb.AppendLine(item.ToString());
            }

            return sb.ToString();
        }

        #endregion


    }
}
