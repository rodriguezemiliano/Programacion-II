public enum EMarca { renault, zanella, scania, ferrari}
public enum EVehiculo { moto, auto, camion}
