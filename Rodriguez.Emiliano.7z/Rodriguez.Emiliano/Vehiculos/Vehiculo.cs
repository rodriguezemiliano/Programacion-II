using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
  public abstract class Vehiculo
  {
    protected string _patente;
    protected EMarca _marca;
    protected int _cantidadRuedas;

    #region Constructores

    public Vehiculo(string patente, EMarca marca, int cantidadRuedas)
    {
      this._patente = patente;
      this._marca = marca;
      this._cantidadRuedas = cantidadRuedas;
    }
    #endregion

    #region Propiedades
    public abstract double Precio { get; set; }

    public EMarca Marca
    {
      get { return this._marca; }
    }
    public string Patente
    {
      get { return this._patente}
    }
    #endregion

    #region Metodos
    public abstract double CalcularPrecioConIva();

    public string MostrarVehiculo()
    {
      return this._patente + " " + this._marca.ToString() + " " + this._cantidadRuedas.ToString();
    }

    public override string ToString()
    {
      return this._patente + this._marca.ToString() + this._cantidadRuedas.ToString();
    }
    #endregion

    #region Operadores

    public static bool operator ==(Vehiculo vehiculo1, Vehiculo vehiculo2)
    {
      return vehiculo1._patente == vehiculo2._patente;
    }
    public static bool operator !=(Vehiculo vehiculo1, Vehiculo vehiculo2)
    {
      return !(vehiculo1 == vehiculo2);
    }

#endregion
  }
}
