using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Vehiculos
{
  public class Auto : Vehiculo
  {
    protected int _cantidadCilindros;

    #region Constructores
    public Auto(string patente, EMarca marca, int cantidadRuedas, int cantidadCilindros) : base(patente, marca, cantidadRuedas)
    {
      _cantidadCilindros = cantidadCilindros;
    }
    #endregion

    #region Propedades
    public override double Precio
    {
      get { return 20000; }
      set { }
    }
    #endregion

    #region Metodos

    public override double CalcularPrecioConIva()
    {
      return this.Precio + this.Precio * 0.2;
    }

    public string MostrarAuto()
    {
      return base.MostrarVehiculo() + " " + this._cantidadCilindros.ToString();
    }

    public override string ToString()
    {
      return base.ToString() + this._cantidadCilindros.ToString();
    }
    #endregion
  }
}
