using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
  public class Camion : Vehiculo
  {
    protected double _tara;

    public Camion(string patente, EMarca marca, int cantidadRuedas, double tara) : base(patente, marca, cantidadRuedas)
    {
      this._tara = tara;
    }

    public override double Precio
    {
      get { return 30000; }
      set { }
    }

    public override double CalcularPrecioConIva()
    {
      return this.Precio + this.Precio * 0.2;
    }

    public string MostrarCamion()
    {
      return base.MostrarVehiculo() + " " + this._tara.ToString();
    }

    public override string ToString()
    {
      return base.ToString() + this._tara.ToString();
    }
  }
}
