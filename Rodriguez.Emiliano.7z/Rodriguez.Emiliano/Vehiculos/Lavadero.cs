using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
  public class Lavadero
  {
    private List<Vehiculo> _vehiculos;
    private double _precioAuto;
    private double _precioMoto;
    private double _precioCamion;

    #region Propiedades
    public string MiLavadero
    {
      get
      {
        string retorno = this._precioMoto.ToString() + this._precioAuto.ToString() + this._precioCamion.ToString(); ;

        foreach (Vehiculo item in this._vehiculos)
        {
          if (item is Moto)
          {
            retorno += ((Moto)item).MostrarMoto();
          }

          else if (item is Auto)
          {
            retorno += ((Auto)item).MostrarAuto();
          }

          else
          {
            retorno += ((Camion)item).MostrarCamion();
          }
        }

        return retorno;
      }
    }

    public List<Vehiculo> Vehiculos
    {

      get
      {
        return this._vehiculos;
      }

    }
    #endregion

    #region Constructores
    public Lavadero()
    {
      this._vehiculos = new List<Vehiculo>();
    }

    public Lavadero(double precioAuto, double precioMoto, double precioCamion)
    {
      this._precioAuto = precioAuto;
      this._precioMoto = precioMoto;
      this._precioCamion = precioCamion;
    }
    #endregion Metodos
    public double MostrarTotalFacturado()
    {
      double retorno = 0.0;

      foreach (Vehiculo item in this._vehiculos)
      {
        if (item is Moto)
        {
          retorno += this._precioMoto;
        }
        else if (item is Auto)
        {
          retorno += this._precioAuto;
        }
        else
        {
          retorno += this._precioCamion;
        }
      }

      return retorno;
    }

    public double MostrarTotalFacturado(EVehiculo tipoVehiculo)
    {
      double retorno = 0.0;

      switch (tipoVehiculo)
      {
        case EVehiculo.moto:

          retorno += this._precioMoto;

          break;

        case EVehiculo.auto:

          retorno += this._precioAuto;

          break;

        case EVehiculo.camion:

          retorno += this._precioCamion;

          break;

        default:
          break;
      }

      return retorno;
    }

    public static int OrdenarVehiculosPorPatente(Vehiculo vehiculo1, Vehiculo vehiculo2)
    {
      return String.Compare(vehiculo1.Patente, vehiculo2.Patente);
    }

    public int OrdebarVehiculosPorPMarca(Vehiculo vehiculo1, Vehiculo vehiculo2)
    {
      return String.Compare(vehiculo1.Marca.ToString(),vehiculo2.Marca.ToString())
    }

    

    #region Operadores
    public static bool operator ==(Lavadero lavadero, Vehiculo vehiculo)
    {
      bool retorno = false;

      foreach (Vehiculo item in lavadero.Vehiculos)
      {
        if (vehiculo == item)
        {
          retorno = true;
        }
      }

      return retorno;

    }

    public static bool operator !=(Lavadero lavadero, Vehiculo vehiculo)
    {
      return !(lavadero == vehiculo);
    }

    public static Lavadero operator +(Lavadero lavadero, Vehiculo vehiculo)
    {

      if (lavadero != vehiculo)
      {
        lavadero._vehiculos.Add(vehiculo);
      }

      return lavadero;
    }

    public static Lavadero operator -(Lavadero lavadero, Vehiculo vehiculo)
    {

      if (lavadero == vehiculo)
      {
        lavadero._vehiculos.Remove(vehiculo);
      }

      return lavadero;
    }
    #endregion

  }
}
