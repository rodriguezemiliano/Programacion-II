﻿public enum ETipoTinta
{
    comun,
    conBrillito,
    China
}