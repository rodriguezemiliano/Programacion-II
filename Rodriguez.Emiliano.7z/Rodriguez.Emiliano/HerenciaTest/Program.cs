using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vehiculos;

namespace HerenciaTest
{
  class Program
  {
    static void Main(string[] args)
    {
      Auto auto1 = new Auto("asd1243", EMarca.ferrari, 4, 6);
      Auto auto2 = new Auto("dfg454", EMarca.renault, 4, 4);
      Moto moto = new Moto("vjj300", EMarca.zanella, 2, 125);
      Camion camion = new Camion("ert345", EMarca.scania, 6, 4);

      Lavadero lavadero = new Lavadero(100, 50, 200);

      lavadero.Vehiculos.Add(auto1);
      lavadero.Vehiculos.Add(auto2);
      lavadero.Vehiculos.Add(moto);
      lavadero.Vehiculos.Add(camion);

      lavadero.OrdebarVehiculosPorPatente();


      // Console.WriteLine(auto1.MostrarAuto());
      // Console.WriteLine(auto2.MostrarAuto());
      // Console.WriteLine(moto.MostrarMoto());
      // Console.WriteLine(camion.MostrarCamion());

      Console.ReadLine();
    }
  }
}
