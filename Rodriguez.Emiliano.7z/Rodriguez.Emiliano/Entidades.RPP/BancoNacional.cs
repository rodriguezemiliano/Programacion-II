using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public class BancoNacional
  {
    public string nombre;
    public string pais;

    public BancoNacional(string nombre, string pais)
    {
      this.nombre  = nombre;
      this.pais = pais;
    }

    public string Mostrar()
    {
      return this.nombre + this.pais;
    }

    public string Mostrar(BancoNacional banco)
    {
      string retorno = "";

      if (banco is BancoProvincial)
      {
        retorno = ((BancoProvincial)banco).Mostrar();
      }
      if (banco is BancoMunicipal)
      {
        retorno = ((BancoMunicipal)banco).Mostrar();
      }
      else
      {
       retorno = banco.Mostrar();
      }
      return banco.Mostrar();
    }

  }
}
