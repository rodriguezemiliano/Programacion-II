using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public class Deposito
  {
    public int capacidad;
    public List<Producto> productos;


   /* public int this[int index]
    {
      get { return productos.Sort(); }

    */






    public Deposito()
    {
      productos = new List<Producto>();
    }

    public Deposito(int capacidad):this()
    {
      this.capacidad = capacidad;
    }

    public static List<Producto> operator +(Deposito a, Deposito b)
    {
      List<Producto> retorno = new List<Producto>();
      
      for (int i = 0; i < a.productos.Count; i++)
      {
        for (int j = 0; j < b.productos.Count; j++)
        {
          if (a.productos[i] == b.productos[j])
          {
            retorno.Add(a.productos[i] + b.productos[j]);

          }
        }
      }


      return retorno;
    }
  }
}
