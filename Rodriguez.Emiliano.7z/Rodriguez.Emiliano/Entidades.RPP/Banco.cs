using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades.RPP
{
  public class Banco
  {
    public string nombre;

    public Banco(string nombre)
    {
      this.nombre = nombre;
    }

    public static bool operator ==(Banco a, Banco B)
    {
      return a.nombre == B.nombre;
    }
    public static bool operator !=(Banco a, Banco B)
    {
      return !(a== B);
    }

    public override bool Equals(object obj)
    {
      bool retorno = false;
      if (obj is Banco)
      {
        if ((Banco)obj == this)
        {

          Console.WriteLine("No es un banco");


          retorno = true;
        }
      }
      else
      {
        Console.WriteLine("No es un banco");
      }
      return retorno;
    }

    
  }
}
