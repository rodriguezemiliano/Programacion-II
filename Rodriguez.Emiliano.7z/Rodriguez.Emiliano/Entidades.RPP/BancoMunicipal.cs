using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public class BancoMunicipal : BancoProvincial
  {
    public string ciudad;

    public BancoMunicipal(BancoProvincial bancoProvincial, string ciuada):base(new BancoNacional(bancoProvincial.nombre,bancoProvincial.pais), bancoProvincial.provincia)
    {
      this.ciudad = ciudad; 
    }

    public static implicit operator string(BancoMunicipal banco)
    {
      return banco.Mostrar(banco);
    }

    public string Mostrar()
    {
      return base.Mostrar() + this.ciudad;
    }
  }
}
