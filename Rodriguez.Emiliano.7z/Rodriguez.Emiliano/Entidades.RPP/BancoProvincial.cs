using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public class BancoProvincial : BancoNacional
  {
    public string provincia;

    public BancoProvincial(BancoNacional bancoNacional, string provincia):base(bancoNacional.nombre, bancoNacional.pais)
    {
      this.provincia = provincia;
    }

    public string Mostrar()
    {
      return base.Mostrar() + this.provincia;
    }
  }
}
