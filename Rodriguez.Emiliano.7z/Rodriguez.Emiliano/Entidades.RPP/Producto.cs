using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public class Producto
  {
    public string nombre;
    public int stock;

    public Producto(string nombre, int stock)
    {
      this.nombre = nombre;
      this.stock = stock;
    }


    public static bool operator ==(Producto a, Producto b)
    {
      return a.nombre == b.nombre;
    }
    public static bool operator !=(Producto a, Producto b)
    {
      return !(a == b);
    }

    public static Producto operator +(Producto a, Producto b)
    {

      a.stock += b.stock;
      return a;
    }
    
  }
}
