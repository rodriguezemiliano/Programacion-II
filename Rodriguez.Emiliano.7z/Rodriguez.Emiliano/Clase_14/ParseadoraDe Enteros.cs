using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_14
{
  public static class ParseadoraDeEnteros 
  {
    public static int numero = 0;



    public static bool Parse(string str_numero)
    {
      bool retorno = false;
      try
      {
        retorno = ParseadoraDeEnteros.TryParse(str_numero, out numero); 
      }
      catch (FormatException e)
      {
        Console.WriteLine(" ERROR DE FORMATO");
        
      }
      catch (OverflowException e)
      {
        Console.WriteLine(" ERROR DE FORMATO");

      }

      return retorno;

    }

    public static bool TryParse(string str_numero, out int numero)
    {
      numero = 0;

      return int.TryParse(str_numero,out numero);

      
    }
  }
}
