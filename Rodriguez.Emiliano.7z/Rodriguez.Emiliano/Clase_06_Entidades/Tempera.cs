using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_06_Entidades
{
  public class Tempera
  {
    private sbyte _cantidad;
    private ConsoleColor _color;
    private String _marca;

    public Tempera(sbyte cantidad, ConsoleColor color, string marca)
    {
      this.Cantidad = cantidad;
      this.Color = color;
      this.Marca = marca;
    }

    public sbyte Cantidad { get => _cantidad; set => _cantidad = value; }
    public ConsoleColor Color { get => _color; set => _color = value; }
    public string Marca { get => _marca; set => _marca = value; }

    public static bool operator ==(Tempera tempera1, Tempera tempera2)
    {
      return (tempera1.Color == tempera2.Color && tempera1.Marca == tempera2.Marca);
    }

    public static bool operator !=(Tempera tempera1, Tempera tempera2)
    {
      return !(tempera1 == tempera2);
    }

    public static implicit operator string(Tempera tempera)
    {
      return tempera.Marca + tempera.Color.ToString() + tempera.Cantidad;
    }

    public static Tempera operator +(Tempera tempera1, Tempera tempera2)
    {

      if (tempera1 == tempera2)
      {
        tempera1 += tempera2;
      }

     return tempera1;
    }
  }
}
