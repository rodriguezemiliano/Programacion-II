using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_06_Entidades
{
  public class Paleta
  {
    private Tempera[] _temperas;
    private int _cantidad;

    public Paleta(Tempera[] temperas, int cantidad)
    {
      this.Temperas = temperas;
      this.Cantidad = cantidad;
    }

    public Tempera[] Temperas { get => _temperas; set => _temperas = value; }
    public int Cantidad { get => _cantidad; set => _cantidad = value; }

    public string Mostrar()
    {
      return this;
    }

    public static bool operator ==(Paleta paleta1, Paleta paleta2)
    {
      bool retorno = false;

      if (paleta1.Cantidad == paleta2.Cantidad)
      {
        retorno = true;

        for (int i = 0; i < paleta1.Cantidad; i++)
        {
          if (paleta1.Temperas[i] != paleta2.Temperas[i])
          {
            retorno = false;
          }
        }
      }
      
      return retorno;
    }

    public static bool operator !=(Paleta paleta1, Paleta paleta2)
    {
      return !(paleta1 == paleta2);
    }

    public static implicit operator string(Paleta paleta)
    {
      StringBuilder retorno = new StringBuilder();

      retorno.Append(paleta.Cantidad.ToString());

      foreach (var tempera in paleta.Temperas)
      {
        retorno.Append(tempera);
      }

      return retorno.ToString();
    }

    public static Paleta operator +(Paleta paleta, Tempera tempera)
    {

      for (int i = 0; i < paleta.Cantidad; i++)
      {
        if (paleta.Temperas[i] == tempera)
        {
          paleta.Temperas[i] += tempera;
        }
      }

      return paleta;
    }
  }
}
