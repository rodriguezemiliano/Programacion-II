public enum ETipoTinta
{
  Comun = 0,
  ConBrillo,
  China
}
