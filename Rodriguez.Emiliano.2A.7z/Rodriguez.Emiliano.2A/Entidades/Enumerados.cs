﻿public enum ETipoProducto{ Tecnologico, Rural, Varios }
public enum EPaises { China, Taiwan, UnionEuropea}
public enum EComercio { Importador, Exportador, Ambos}