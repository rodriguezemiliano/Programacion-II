﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Comercio
    {
        private int cantidadDeEmpleados;
        protected Comerciante _comerciante;
        protected Random _generadoreEmpleados;
        protected string _nombre;
        protected float _precioAlquiler;

        //CONSTRUCTORES

        static Comercio()
        {
            
        }

        public Comercio(Comerciante comerciante, string nombre, float precioAlquiler)
        {
            this._nombre = nombre;
            this._precioAlquiler = precioAlquiler;
            this._comerciante = comerciante;
        }

        public Comercio(float precioAlquiler, string nombreComercio, string nombre, string apellido):this(new Comerciante(apellido,nombre), nombreComercio, precioAlquiler)
        {
           
        }

        protected int CantidadDeEmpleados
        {
            get
            {
                
                if (cantidadDeEmpleados == 0)
                {
                     cantidadDeEmpleados = _generadoreEmpleados.Next(1, 100);
                }
                return cantidadDeEmpleados;
            }
        }

        //METODOS

        private static string Mostrar(Comercio comercio)
        {
            return comercio._nombre + " " + comercio._comerciante + " " + comercio._precioAlquiler + " " + comercio.CantidadDeEmpleados;
        }



        //OPERADORES
        public static bool operator ==(Comercio a, Comercio b)
        {
            return (a._nombre == b._nombre && a._comerciante == b._comerciante);
        }
        public static bool operator !=(Comercio a, Comercio b)
        {
            return !(a == b);
        }

        public static explicit operator string(Comercio comercio)
        {
            return Mostrar(comercio);
        }
    }
}
