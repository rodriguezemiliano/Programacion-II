﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Shopping
    {
        private int _capacidad;
        private List<Comercio> _comercios;

        private Shopping()
        {
            this._comercios = new List<Comercio>();            
        }

        private Shopping(int capacidad):this()
        {
            this._capacidad = capacidad;
        }

        //PROPIEDADES
        public double PrecioDeExpotadores
        {
            get
            {
                double retorno = 0.0;

                foreach (Comercio item in this._comercios)
                {
                    if(item is Exportador)
                    {
                        retorno += ((Exportador)item);
                    }

                }

                return retorno;
            }
        }

        public double PrecioDeImportador
        {
            get
            {
                double retorno = 0.0;

                foreach (Comercio item in this._comercios)
                {
                    if (item is Importador)
                    {
                        retorno += ((Importador)item);
                    }

                }

                return retorno;
            }
        }

        public double PrecioTotal
        {
            get
            {
                double retorno = 0.0;

                foreach (Comercio item in this._comercios)
                {
                    if (item is Importador)
                    {
                        retorno += PrecioDeImportador;
                    }
                    else
                    {
                        retorno += PrecioDeExpotadores;
                    }

                }

                return retorno;
            }
        }


        //METODOS

        private double ObtenerPrecio(EComercio tipoComerrcio)
        {
            double retorno = 0.0;

            switch (tipoComerrcio)
            {
                case EComercio.Importador: retorno = PrecioDeImportador;
                    break;
                case EComercio.Exportador: retorno = PrecioDeExpotadores;
                    break;
                case EComercio.Ambos:  retorno = PrecioTotal;
                    break;
                default:
                    break;
            }

            return retorno;
        }

        public static string Mostrar(Shopping shopping)
        {
            StringBuilder sb = new StringBuilder();

            foreach (Comercio item in shopping._comercios)
            {
                if(item is Exportador)
                {
                    sb.AppendLine(((Exportador)item).Mostrar());
                }
                else
                {
                    sb.AppendLine(((Importador)item).Mostrar());
                }
            }
            

            return sb.ToString();
        }

        public static bool operator ==(Shopping shopping, Comercio comercio)
        {
            bool retorno = false;

            foreach (Comercio item in shopping._comercios)
            {
                if (item == comercio)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Shopping shopping, Comercio comercio)
        {
            return !(shopping == comercio);
        }

        public static Shopping operator +(Shopping shopping, Comercio comercio)
        {

            if(shopping._capacidad > shopping._comercios.Capacity && shopping != comercio)
            {
                shopping._comercios.Add(comercio);
            }

            return shopping;
        }

        public static implicit  operator Shopping(int capacidad)
        {
            return new Shopping(capacidad);
        }
    }
}
