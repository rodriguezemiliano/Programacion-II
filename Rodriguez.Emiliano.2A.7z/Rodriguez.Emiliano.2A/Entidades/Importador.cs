﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Importador : Comercio
    {
        public EPaises paisOrigen;

        public Importador(string nombreComercio, float precioAlquiler, Comerciante comerciante, EPaises paisOrigen):base(comerciante,nombreComercio,precioAlquiler)
        {
            this.paisOrigen = paisOrigen;
        }

        //METODOS
        public string Mostrar()
        {
            return (string)this; //+ " " + this.paisOrigen.ToString();
        }

        //OPERADORES
        public static bool operator ==(Importador a, Importador b)
        {
            return (a == b && a.paisOrigen == b.paisOrigen);
        }
        public static bool operator !=(Importador a, Importador b)
        {
            return (a == b);
        }

        public static implicit operator double(Importador importador)
        {
            return importador._precioAlquiler;
        }
    }
}
