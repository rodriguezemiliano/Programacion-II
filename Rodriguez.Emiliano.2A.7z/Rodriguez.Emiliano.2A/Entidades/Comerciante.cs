﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Comerciante
    {
        private string _apellido;
        private string _nombre;

        public Comerciante(string apellido, string nombre)
        {
            _apellido = apellido;
            _nombre = nombre;
        }

        //OPERADORES
        public static bool operator ==(Comerciante a, Comerciante b)
        {
            return (a._nombre == b._nombre && a._apellido == b._apellido);
        }
        public static bool operator !=(Comerciante a, Comerciante b)
        {
            return !(a == b);
        }

        public static implicit operator string (Comerciante comerciante)
        {
            return comerciante._nombre + " " + comerciante._apellido;
        }
    }
}
