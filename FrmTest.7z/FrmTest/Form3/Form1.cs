﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FrmTest;

namespace Form3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(this.Inicializar);
        }

        private void Inicializar(object sender, EventArgs e)
        {
            this.button1.Click += new EventHandler(this.MiManejador);
            //this.button4.Click += new EventHandler(this.button4);
            // this.button2.Click += new EventHandler(this.MiManejador);
            // this.button3.Click += new EventHandler(this.MiManejador);
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void MiManejador(object sender, EventArgs e)
        {
            if (sender is Button)
            {

                if (sender == this.button1)
                {
                    MessageBox.Show(((Button)sender).Name);
                    ((Button)sender).Click -= new EventHandler(this.MiManejador);
                    this.button2.Click += new EventHandler(this.MiManejador);
                }
                if (sender == this.button2)
                {
                    MessageBox.Show(((Button)sender).Name);
                    ((Button)sender).Click -= new EventHandler(this.MiManejador);
                    this.button3.Click += new EventHandler(this.MiManejador);
                }
                if (sender == this.button3)
                {
                    MessageBox.Show(((Button)sender).Name);
                    ((Button)sender).Click -= new EventHandler(this.MiManejador);
                    this.button1.Click += new EventHandler(this.MiManejador);
                }

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MiDelegado delegado = new MiDelegado(Manejadora.Sumar);

            delegado.Invoke(3,2);

            MiDelegado delegado2 = new MiDelegado((new Manejadora()).Restar);

            delegado2.Invoke(5,3);

            MiDelegado delegado3 = delegado;

            MessageBox.Show( delegado2.Target.ToString());
            MessageBox.Show(delegado2.GetInvocationList().ToString());

            Delegate[] lista = delegado2.GetInvocationList();

            
            foreach (MiDelegado item in lista)
            {
                MessageBox.Show(item.Target.ToString());
            }

        }
    }
}
