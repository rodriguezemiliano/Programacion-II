﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.btn_Boton.Click    += new EventHandler(Manejadora.Manejador);
            this.textBox1.Click     += new EventHandler(Manejadora.Manejador);
            this.lbl_Titulo.Click   += new EventHandler(Manejadora.Manejador);
            //this.btn_Boton.Click    += new EventHandler(new Manejadora().ManejadorInstancia);
            //this.textBox1.Click     += new EventHandler(new Manejadora().ManejadorInstancia);
            //this.lbl_Titulo.Click   += new EventHandler(new Manejadora().ManejadorInstancia);
        
        }

        private void MostrarMensaje(object sender, EventArgs e)
        {
            MessageBox.Show("Click dsd el boton");
           // this.lbl_Titulo.Click += new System.EventHandler(this.lbl_Titulo_Click);
          //  this.textBox1.Click += new System.EventHandler(this.textBox1_Click);


        }

       /* private void lbl_Titulo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Click dsd el label");
            this.lbl_Titulo.Click -= new System.EventHandler(this.lbl_Titulo_Click);
        }*/

        

        /*private void textBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Click dsd el TextBox");
        }*/
    }
}
