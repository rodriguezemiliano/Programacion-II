﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FrmTest
{
    public class Manejadora
    {
        public static void Manejador (Object obj, EventArgs e)
        {
            //MessageBox.Show("Estoy dentro de laclase manejadora");

            if (obj is Label)
            {
                MessageBox.Show("Label");
            }
            if (obj is TextBox)
            {
                MessageBox.Show("TextBox");
            }
            if (obj is Button)
            {
                MessageBox.Show("Boton");
            }
        }

        public void ManejadorInstancia(Object obj, EventArgs e)
        {
            MessageBox.Show("Estoy dentro de laclase manejadora");
        }

        public static void Sumar(int a, int b)
        {
            MessageBox.Show((a + b).ToString());
        }
        public  void Restar(int a, int b)
        {
            MessageBox.Show((a - b).ToString());

        }


    }
}
