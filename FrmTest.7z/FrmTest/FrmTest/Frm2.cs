﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmTest
{
    public partial class Frm2 : Form
    {
        public Frm2()
        {
            InitializeComponent();
            this.Load += new EventHandler(this.Inicializar);
        }

        private void Inicializar(object sender, EventArgs e)
        {
            this.button1.Click += new EventHandler(this.MiManejador);
        }

        private void MiManejador(object sender, EventArgs e)
        {
            MessageBox.Show(this.button1.Name);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void Frm2_Load(object sender, EventArgs e)
        {

        }
    }
}
